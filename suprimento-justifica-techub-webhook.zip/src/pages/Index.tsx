import SupplyJustificationForm from "@/components/SupplyJustificationForm";

const Index = () => {
  return <SupplyJustificationForm />;
};

export default Index;
